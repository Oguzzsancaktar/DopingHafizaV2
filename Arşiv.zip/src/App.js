import './App.css';
import { Body, Footer, Header } from './components';

function App() {
  return (
    <>
     <Header/>
     <Body/>
     <Footer/>
    </>
  );
}

export default App;
