import React, { Component } from "react";
import "./bodyCss/accordion.scss";
import faqsData from "../../../fixtures/faqs.json";
import Video from '../../../images/Video.png'

export default class Accordion extends Component {
  componentDidMount() {
    const accordionItems = document.querySelectorAll("[data-accordion-item]");

    accordionItems.forEach((item) => {
      const button = item.querySelector("[data-accordion-button]");
      const icon = item.querySelector("[data-accordion-button-icon]");
      const content = item.querySelector("[data-accordion-content]");

      window.addEventListener("resize", () => {
        if (content.getAttribute("data-accordion-content") === "open") {
          content.style.height = "auto";

          const contentHeight = content.scrollHeight;
          content.style.height = `${contentHeight}px`;
        }
      });

      button.addEventListener("click", () => {
        if (content.getAttribute("data-accordion-content") !== "open") {
          const contentHeight = content.scrollHeight;

          icon.setAttribute("data-accordion-button-icon", "open");
          content.setAttribute("data-accordion-content", "open");
          content.style.height = `${contentHeight}px`;
        } else {
          icon.setAttribute("data-accordion-button-icon", "closed");
          content.setAttribute("data-accordion-content", "closed");
          content.style.height = "0";
        }
      });
    });
  }
  render() {
    return (
      <div className="Accordion">
     
          <>
            <section class="header">
              <h2>Merak edilen sorular ?</h2>
              <p>En çok merak edilen konuları birrarada topladık.</p>
            </section>
            <section class="accordion">
            {faqsData.map((item) => (
              <article class="accordion__item" data-accordion-item>
                <button
                  class="accordion__button"
                  data-accordion-button
                >
                  
                </button>
                <div class="hb">
                <p class="accordion__item-header">
                 {item.question}
               
                </p>
                 <span
                    class="accordion__item-header-icon"
                    data-accordion-button-icon
                  > </span></div>
                <div class="accordion__content" data-accordion-content>
                  <p>
                   {item.answer1}
                   <br/>
                   <br/>
                   {item.answer2}
                  </p>

                  <video src="" poster={Video}></video>
                </div>
              </article>
                 ))}
            </section>
          </>
     
      </div>
    );
  }
}
