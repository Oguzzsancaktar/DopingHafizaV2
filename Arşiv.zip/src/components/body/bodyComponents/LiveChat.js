import React, { Component } from "react";
import chat from "../../../images/Chat.png";
import './bodyCss/liveChat.scss'

export default class LiveChat extends Component {
  render() {
    return (
      <div className="LiveChat">
        <div className="container">
          
              <div className="img_bg" >
                <img src={chat} alt="" />
              </div>
            
           
              <p>
                Dilerseniz <b>Doping Hafıza Uzmanlarımıza danışabilir,</b> merak
                ettiklerinizi en hızlı şekilde cevaplayabiliriz.
              </p>
            
          
              {" "}
              <button> Konuşma Başlat </button>{" "}
       
        </div>
      </div>
    );
  }
}
