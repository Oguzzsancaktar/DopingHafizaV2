console.clear();

const { useState, useRef, useLayoutEffect, useEffect } = React;

function SearchInput({ query, onChange }) {
  return (
    <label className="search">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="48"
        height="48"
        viewBox="0 0 24 24"
        fill="none"
        stroke="#000000"
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <circle cx="11" cy="11" r="8" />
        <line x1="21" y1="21" x2="16.65" y2="16.65" />
      </svg>

      <input
        className="search-input"
        placeholder="Search for dog breeds"
        type="search"
        defaultValue={query}
        onChange={event => {
          onChange(event.target.value);
        }}
      />
    </label>
  );
}

function Result({ children, style }) {
  const elRef = useRef(null);
  const topRef = useRef(0);
  
  // TODO: Get dy working
  const [top, setTop] = useState(null);
  const [dy, setDy] = useState(0);
  
//   useEffect(() => {
//     if (!elRef.current) return;
    
//     const nextTop = elRef.current.getBoundingClientRect().top;
    
//     if (nextTop === topRef.current) return;
    
//     const deltaY = nextTop - topRef.current;
    
//     topRef.current = nextTop;
    
//     setDy(deltaY);
    
//     requestAnimationFrame(() => {
//       setDy(0);
//     });
//   });
  
  return (
    <li 
      style={{
        ...style,
        '--dy': dy
      }} 
      className="result-item" 
      ref={elRef}>
      {children}
    </li>
  );
}

function Results({ data = [] }) {
  const elRef = useRef(null);

  const [height, setHeight] = useState(null);
  useLayoutEffect(() => {
    if (!elRef.current) return;
    const rect = elRef.current.getBoundingClientRect();
    setHeight(rect.height);
  });

  return (
    <ul
      className="results"
      ref={elRef}
      style={{ "--height": height }}
      data-height={height}
    >
      {data.map((item, i) => {
        return (
          <Result
            key={item}
            style={{
              "--i": i
            }}
          >
            {item}
          </Result>
        );
      })}
    </ul>
  );
}

function App() {
  const [query, setQuery] = useState("dog");
  const results =
    query.length < 2
      ? []
      : dogBreeds
          .filter(dogBreed => {
            return dogBreed.includes(query);
          })
          .slice(0, 5);

  return (
    <div className="searchbar">
      <SearchInput onChange={setQuery} query={query} />
      <Results data={results} />
    </div>
  );
}


