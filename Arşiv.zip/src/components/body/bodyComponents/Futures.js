import React, { Component } from "react";
import futureData from "../../../fixtures/futures.json";
import "./bodyCss/futures.scss";

import img1 from "../../../images/WeirdoHead.png";
import img2 from "../../../images/Package.png";
import img3 from "../../../images/Basket.png";
import img4 from "../../../images/Refund.png";
import button from "../../../images/ic_up.png";


const images = [img1, img2, img3, img4];
let img = img1;

export default class Futures extends Component {
  render() {
    console.log(img);

    return (
      <div className="Futures">
        <div className="container">
          <div className="header">
            <h2>Yararlı bulabileceğiniz konu başlıkları</h2>
            <p>
              Doping Hafıza Online Eğitim Platformu ile ilgili merak edilen konu
              başlıklarına aşağıdan ulaşabilirsiniz.
            </p>
          </div>

          <div className="row__items">
            {futureData.map((item) => (
              <div>
                <ul>
                  <li>
                    {item.id == 1 ? <img src={img1} alt="" /> : null}
                    {item.id == 2 ? <img src={img2} alt="" /> : null}
                    {item.id == 3 ? <img src={img3} alt="" /> : null}
                    {item.id == 4 ? <img src={img4} alt="" /> : null}
                  </li>

                  <li>
                    <h3>{item.header}</h3>
                  </li>
                  <li>
                    <p>{item.title1}</p>
                  </li>
                  <li>
                    <p>{item.title2}</p>
                  </li>
                  <li>
                    <p>{item.title3}</p>
                  </li>
                  <li>
                    <p>{item.title4}</p>
                  </li>
                  <li>
                    <p>{item.title5}</p>
                  </li>
                  <li>
                    <a href="#"> Tümünü Göster</a> <img src={button} alt="" />{" "}
                  </li>
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
}
