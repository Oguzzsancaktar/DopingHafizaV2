import React, { useState } from "react";
import DATA from "../../../fixtures/faqs.json";
import './bodyCss/searchbar.scss'
import SearchImg from '../../../images/SearchArticle.png'


export default function SearchBar() {
  const [searchTerm, setSearchTerm] = useState("-");
  return (
    <div className="Searchbar">
        <div className="searchArea">
            <div>
            <ul>
                <li><img src={SearchImg} alt=""/></li>
                <li> <input
        type="text"
        placeholder="Arama yapınız"
        onChange={(event) => {
          setSearchTerm(event.target.value);
        }}
      /></li>
            </ul>
           
        </div>
      
      {DATA.filter((val) => {
        if (searchTerm == "") {
          return val="-";
        } else if (
          val.question
            .toLocaleLowerCase()
            .includes(searchTerm.toLocaleLowerCase())
        ) {
          return val;
        }
      }).map((val, key) => {
        return (
          <div className="questions" key={key}>
            {" "}
            <p>{val.question} </p>
          </div>
        );
      })}
      </div>
    </div>
  );
}
