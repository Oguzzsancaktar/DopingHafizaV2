import React, { Component } from 'react'
import './bodyCss/search.scss'
import SearchBar from './SearchBar'

export default class Search extends Component {
    render() {
        return (
            <div className="Search">
                <div className="container-fluid">
                    <div className="wrapper">
                        <h2>Sorun Yaşıyorsanız</h2>
                        <h1>Yardım için buradayız.</h1>
        <SearchBar/>
        
                                    

                    </div>
                </div>
                
            </div>
        )
    }
}
