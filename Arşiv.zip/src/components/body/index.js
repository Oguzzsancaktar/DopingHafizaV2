import React, { Component } from 'react'
import Accordion from './bodyComponents/Accordion'
import Futures from './bodyComponents/Futures'
import LiveChat from './bodyComponents/LiveChat'
import Search from './bodyComponents/Search'


export default class Body extends Component {
    
    render() {

        return (
            <div>
                <Search/>
                <Accordion/>
                <Futures/>
                <LiveChat/>
             
            </div>
        )
    }
}
