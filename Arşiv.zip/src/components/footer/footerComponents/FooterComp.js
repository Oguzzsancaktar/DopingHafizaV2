import React, { Component } from 'react'
import '../footerCss/footer.scss'

import Bip from '../../../images/Bip.png'
import Facebook from '../../../images/Facebook.png'
import Telegram from '../../../images/Telegram.png'
import Twitter from '../../../images/Twitter.png'
import Youtube from '../../../images/Youtube.png'
import Instagram from '../../../images/Instagram.png'


export default class FooterComp extends Component {

    
    render() {
const footerIcons = [ Facebook , Instagram,Twitter , Youtube , Telegram ,Bip]

        return (
            <div className="Footer">
                <div className="wrap">
                    <ul>
                        {footerIcons.map(icons=>(
                             <li><img src={icons} alt=""/> </li> 
                        ))}
                     
                      

                    </ul>
                </div>
            </div>
        )
    }
}
