import React, { Component } from 'react'
import FooterComp from './footerComponents/FooterComp'
export default class Footer extends Component {
    render() {
        return (
            <div>
                <FooterComp/>
            </div>
        )
    }
}
