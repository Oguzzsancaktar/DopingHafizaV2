import React, { Component } from 'react'
import HeaderMain from './headerComponents/HeaderMain'
import HeaderRoute from './headerComponents/HeaderRoute'
import HeaderTop from './headerComponents/HeaderTop'

export default class Header extends Component {
    render() {
        return (
            <div>

                <HeaderTop/>
                <HeaderMain/>
                <HeaderRoute/>
          
            </div>
        )
    }
}
