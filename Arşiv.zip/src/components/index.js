export {default as Header} from './header'
export {default as Body} from './body'
export {default as Footer} from './footer'

